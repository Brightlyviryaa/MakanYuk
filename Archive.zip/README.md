**Selamat Datang Di Project MakanYuk**

_Berikut adalah link design dari makan yuk, gunakan untuk developing_
https://www.figma.com/file/HMUUl5XVRBK23uAbDjcpNE/MakanYuk!?type=design&node-id=2-2&mode=design&t=qne8m2WPfHkMVcQH-0

**Kalo NgeBUG jangan di push di benerin dulu BUG nya**

**Baca Note:**

- Commit Message harus sesuai dengan apa yang di ubah, jangan ngaco.
- Tolong komunikasikan di group kalian lagi mau mulai kerjain bagian mana dan kalo sudah selesi komunikasikan lagi bahwa sudah selesai dan sudah di commit
